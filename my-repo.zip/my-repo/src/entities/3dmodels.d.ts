// Re-export from main entities file for backward compatibility
export type { _3DModels } from './index';
