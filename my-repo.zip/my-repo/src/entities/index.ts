/**
 * Auto-generated entity types
 * Contains all CMS collection interfaces in a single file 
 */

/**
 * Collection ID: 3dmodels
 * Interface for _3DModels
 */
export interface _3DModels {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  modelName?: string;
  /** @wixFieldType url */
  modelUrl?: string;
  /** @wixFieldType text */
  caseId?: string;
  /** @wixFieldType text */
  modelType?: string;
  /** @wixFieldType datetime */
  creationTimestamp?: Date | string;
  /** @wixFieldType number */
  processingTimeSeconds?: number;
  /** @wixFieldType text */
  description?: string;
}


/**
 * Collection ID: activitylogs
 * Interface for ActivityLogs
 */
export interface ActivityLogs {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  actionType?: string;
  /** @wixFieldType text */
  performedBy?: string;
  /** @wixFieldType datetime */
  timestamp?: Date | string;
  /** @wixFieldType text */
  description?: string;
  /** @wixFieldType text */
  relatedEntityId?: string;
  /** @wixFieldType text */
  relatedEntityType?: string;
}


/**
 * Collection ID: cases
 * Interface for Cases
 */
export interface Cases {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  title?: string;
  /** @wixFieldType text */
  description?: string;
  /** @wixFieldType text */
  location?: string;
  /** @wixFieldType date */
  incidentDate?: Date | string;
  /** @wixFieldType text */
  assignedOfficer?: string;
}


/**
 * Collection ID: evidence
 * Interface for Evidence
 */
export interface Evidence {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType image - Contains image URL, render with <Image> component, NOT as text */
  evidenceImage?: string;
  /** @wixFieldType text */
  category?: string;
  /** @wixFieldType datetime */
  timestamp?: Date | string;
  /** @wixFieldType text */
  location?: string;
  /** @wixFieldType text */
  notes?: string;
}
