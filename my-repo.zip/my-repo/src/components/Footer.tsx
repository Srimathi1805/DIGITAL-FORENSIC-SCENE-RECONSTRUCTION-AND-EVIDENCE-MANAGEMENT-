import { Link } from 'react-router-dom';
import { Shield, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full border-t border-primary/20 bg-code-background">
      <div className="max-w-[100rem] mx-auto px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/30">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <span className="font-heading font-bold text-lg">Digital Forensics</span>
            </div>
            <p className="font-paragraph text-sm text-foreground/60 leading-relaxed">
              Advanced evidence management and 3D scene reconstruction platform for forensic professionals.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-heading font-bold text-lg mb-4 text-primary">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="font-paragraph text-sm text-foreground/70 hover:text-primary transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="font-paragraph text-sm text-foreground/70 hover:text-primary transition-colors">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link to="/cases" className="font-paragraph text-sm text-foreground/70 hover:text-primary transition-colors">
                  Cases
                </Link>
              </li>
              <li>
                <Link to="/reports" className="font-paragraph text-sm text-foreground/70 hover:text-primary transition-colors">
                  Reports
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-heading font-bold text-lg mb-4 text-secondary">Resources</h3>
            <ul className="space-y-3">
              <li>
                <span className="font-paragraph text-sm text-foreground/70">Documentation</span>
              </li>
              <li>
                <span className="font-paragraph text-sm text-foreground/70">API Reference</span>
              </li>
              <li>
                <span className="font-paragraph text-sm text-foreground/70">Training Materials</span>
              </li>
              <li>
                <span className="font-paragraph text-sm text-foreground/70">Support Center</span>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-heading font-bold text-lg mb-4 text-accent-muted">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-primary" />
                <span className="font-paragraph text-sm text-foreground/70">support@forensics.sys</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-primary" />
                <span className="font-paragraph text-sm text-foreground/70">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="font-paragraph text-sm text-foreground/70">Secure Location</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-primary/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="font-paragraph text-sm text-foreground/50">
            © {currentYear} Digital Forensics System. All rights reserved.
          </p>
          <div className="flex gap-6">
            <span className="font-paragraph text-sm text-foreground/50 hover:text-primary transition-colors cursor-pointer">
              Privacy Policy
            </span>
            <span className="font-paragraph text-sm text-foreground/50 hover:text-primary transition-colors cursor-pointer">
              Terms of Service
            </span>
            <span className="font-paragraph text-sm text-foreground/50 hover:text-primary transition-colors cursor-pointer">
              Security
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
