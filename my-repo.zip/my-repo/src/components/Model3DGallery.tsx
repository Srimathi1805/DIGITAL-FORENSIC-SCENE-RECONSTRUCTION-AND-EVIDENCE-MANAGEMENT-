import { useState, useEffect } from 'react';
import { BaseCrudService } from '@/integrations';
import { _3DModels } from '@/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { motion } from 'framer-motion';
import { Trash2, Eye } from 'lucide-react';
import Model3DViewer from './Model3DViewer';
import { Image } from '@/components/ui/image';

interface Model3DGalleryProps {
  caseId: string;
  onModelsChange?: () => void;
}

export default function Model3DGallery({ caseId, onModelsChange }: Model3DGalleryProps) {
  const [models, setModels] = useState<_3DModels[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedModel, setSelectedModel] = useState<_3DModels | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    loadModels();
  }, [caseId]);

  const loadModels = async () => {
    setIsLoading(true);
    try {
      const result = await BaseCrudService.getAll<_3DModels>('3dmodels', {}, { limit: 100 });
      const caseModels = result.items.filter((m) => m.caseId === caseId);
      setModels(caseModels);
    } catch (error) {
      console.error('Failed to load models:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (modelId: string) => {
    if (!window.confirm('Are you sure you want to delete this 3D model?')) {
      return;
    }

    setDeletingId(modelId);
    try {
      await BaseCrudService.delete('3dmodels', modelId);
      setModels(models.filter((m) => m._id !== modelId));
      onModelsChange?.();
    } catch (error) {
      console.error('Failed to delete model:', error);
    } finally {
      setDeletingId(null);
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-code-background border-primary/20">
        <CardHeader>
          <CardTitle className="font-heading text-2xl">3D Models</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-16">
          <LoadingSpinner />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-code-background border-primary/20">
        <CardHeader>
          <CardTitle className="font-heading text-2xl">3D Models ({models.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {models.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {models.map((model, index) => (
                <motion.div
                  key={model._id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="group relative"
                >
                  <div className="aspect-square rounded-lg overflow-hidden bg-background border border-primary/20 group-hover:border-primary/40 transition-all">
                    {model.modelUrl && model.modelType === 'reconstructed' && (
                      <Image src={model.modelUrl} alt={model.modelName || 'Model'} className="w-full h-full object-cover" />
                    )}
                    {model.modelType === 'glb' && (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20">
                        <div className="text-center">
                          <p className="font-heading text-2xl text-primary mb-2">🎯</p>
                          <p className="font-paragraph text-xs text-foreground/60">GLB Model</p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-3">
                    <p className="font-paragraph font-medium text-foreground truncate">
                      {model.modelName}
                    </p>
                    <p className="font-paragraph text-xs text-foreground/60 mt-1">
                      {model.modelType === 'glb' ? '🎯 GLB' : '📸 Reconstructed'}
                      {model.processingTimeSeconds ? ` • ${model.processingTimeSeconds}s` : ''}
                    </p>
                  </div>

                  {/* Hover Actions */}
                  <div className="absolute inset-0 rounded-lg bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button
                      onClick={() => setSelectedModel(model)}
                      size="sm"
                      className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    <Button
                      onClick={() => handleDelete(model._id)}
                      disabled={deletingId === model._id}
                      size="sm"
                      variant="outline"
                      className="border-destructive/50 text-destructive hover:bg-destructive/10 rounded-md"
                    >
                      {deletingId === model._id ? (
                        <div className="w-4 h-4 border-2 border-destructive/30 border-t-destructive rounded-full animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="font-heading text-2xl text-foreground/40 mb-2">🎯</p>
              <p className="font-paragraph text-lg text-foreground/60">
                No 3D models yet
              </p>
              <p className="font-paragraph text-sm text-foreground/50 mt-2">
                Upload images or GLB files to create 3D models
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 3D Viewer Modal */}
      {selectedModel && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedModel(null)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-4xl max-h-[90vh] overflow-y-auto"
          >
            <Model3DViewer
              modelUrl={selectedModel.modelUrl || ''}
              modelName={selectedModel.modelName || 'Model'}
              modelType={selectedModel.modelType as 'glb' | 'reconstructed'}
              onClose={() => setSelectedModel(null)}
            />
          </motion.div>
        </motion.div>
      )}
    </>
  );
}
