import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { useMember } from '@/integrations';
import { Cases, Evidence, ActivityLogs } from '@/entities';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Image } from '@/components/ui/image';
import { ArrowLeft, MapPin, Calendar, User, Upload, Edit, Trash2, FileText, Box } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Model3DGallery from '@/components/Model3DGallery';
import { format } from 'date-fns';

export default function CaseDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const { member } = useMember();
  const navigate = useNavigate();
  const [caseData, setCaseData] = useState<Cases | null>(null);
  const [evidence, setEvidence] = useState<Evidence[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (id) {
      loadCaseData();
    }
  }, [id]);

  const loadCaseData = async () => {
    setIsLoading(true);
    try {
      const caseResult = await BaseCrudService.getById<Cases>('cases', id!);
      setCaseData(caseResult);

      // Load all evidence and filter by case
      const evidenceResult = await BaseCrudService.getAll<Evidence>('evidence', {}, { limit: 100 });
      setEvidence(evidenceResult.items);
    } catch (error) {
      console.error('Failed to load case:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this case? This action cannot be undone.')) {
      return;
    }

    setIsDeleting(true);
    try {
      await BaseCrudService.delete('cases', id!);

      // Log activity
      const activityLog: ActivityLogs = {
        _id: crypto.randomUUID(),
        actionType: 'CASE_DELETED',
        performedBy: member?.profile?.nickname || member?.loginEmail || 'Unknown',
        timestamp: new Date().toISOString(),
        description: `Deleted case: ${caseData?.title}`,
        relatedEntityId: id,
        relatedEntityType: 'case'
      };
      await BaseCrudService.create('activitylogs', activityLog);

      navigate('/cases');
    } catch (error) {
      console.error('Failed to delete case:', error);
      setIsDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh] flex items-center justify-center">
          <LoadingSpinner />
        </main>
        <Footer />
      </div>
    );
  }

  if (!caseData) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <h2 className="font-heading text-3xl font-bold mb-4">Case Not Found</h2>
            <p className="font-paragraph text-foreground/70 mb-6">
              The case you're looking for doesn't exist or has been removed.
            </p>
            <Button
              onClick={() => navigate('/cases')}
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md"
            >
              Back to Cases
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <main className="max-w-[100rem] mx-auto px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Back Button */}
          <Button
            onClick={() => navigate('/cases')}
            variant="ghost"
            className="mb-8 text-foreground/70 hover:text-primary hover:bg-primary/10 rounded-md"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Cases
          </Button>

          {/* Header with Actions */}
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-12">
            <div>
              <h1 className="font-heading text-5xl font-bold mb-4">{caseData.title}</h1>
              <p className="font-paragraph text-lg text-foreground/70">
                Case ID: {caseData._id.slice(0, 8).toUpperCase()}
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button
                onClick={() => navigate(`/cases/${id}/models`)}
                className="bg-secondary text-secondary-foreground hover:bg-secondary/90 rounded-md font-paragraph font-semibold"
              >
                <Box className="w-4 h-4 mr-2" />
                3D Models
              </Button>
              <Button
                onClick={() => navigate(`/cases/${id}/upload-evidence`)}
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md font-paragraph font-semibold"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload Evidence
              </Button>
              <Button
                onClick={() => navigate(`/cases/${id}/edit`)}
                variant="outline"
                className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md"
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
              <Button
                onClick={handleDelete}
                disabled={isDeleting}
                variant="outline"
                className="border-destructive/50 text-destructive hover:bg-destructive/10 rounded-md"
              >
                {isDeleting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-destructive/30 border-t-destructive rounded-full animate-spin mr-2" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Case Details */}
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            <Card className="bg-code-background border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-paragraph text-sm text-foreground/60 mb-1">Location</p>
                    <p className="font-paragraph font-medium">{caseData.location || 'Not specified'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-code-background border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center flex-shrink-0">
                    <Calendar className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <p className="font-paragraph text-sm text-foreground/60 mb-1">Incident Date</p>
                    <p className="font-paragraph font-medium">
                      {caseData.incidentDate ? format(new Date(caseData.incidentDate), 'MMM dd, yyyy') : 'Not specified'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-code-background border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-accent-muted/10 flex items-center justify-center flex-shrink-0">
                    <User className="w-6 h-6 text-accent-muted" />
                  </div>
                  <div>
                    <p className="font-paragraph text-sm text-foreground/60 mb-1">Assigned Officer</p>
                    <p className="font-paragraph font-medium">{caseData.assignedOfficer || 'Unassigned'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Description */}
          <Card className="bg-code-background border-primary/20 mb-12">
            <CardHeader>
              <CardTitle className="font-heading text-2xl">Case Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-paragraph text-foreground/80 leading-relaxed whitespace-pre-wrap">
                {caseData.description}
              </p>
            </CardContent>
          </Card>

          {/* 3D Models Section */}
          <div className="mb-12">
            <Model3DGallery caseId={id!} />
          </div>

          {/* Evidence Section */}
          <Card className="bg-code-background border-primary/20">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="font-heading text-2xl">Evidence ({evidence.length})</CardTitle>
              <Button
                onClick={() => navigate(`/cases/${id}/upload-evidence`)}
                size="sm"
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload
              </Button>
            </CardHeader>
            <CardContent>
              {evidence.length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {evidence.map((item, index) => (
                    <motion.div
                      key={item._id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className="group relative"
                    >
                      <div className="aspect-square rounded-lg overflow-hidden bg-background border border-primary/20 group-hover:border-primary/40 transition-all">
                        {item.evidenceImage ? (
                          <Image
                            src={item.evidenceImage}
                            alt={item.category || 'Evidence'}
                            width={400}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <FileText className="w-12 h-12 text-foreground/30" />
                          </div>
                        )}
                      </div>
                      <div className="mt-3">
                        {item.category && (
                          <p className="font-paragraph text-sm font-medium text-primary mb-1">
                            {item.category}
                          </p>
                        )}
                        {item.location && (
                          <p className="font-paragraph text-xs text-foreground/60">
                            📍 {item.location}
                          </p>
                        )}
                        {item.timestamp && (
                          <p className="font-paragraph text-xs text-foreground/50 mt-1">
                            {format(new Date(item.timestamp), 'MMM dd, yyyy HH:mm')}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <FileText className="w-16 h-16 text-foreground/20 mx-auto mb-4" />
                  <p className="font-paragraph text-lg text-foreground/60 mb-6">
                    No evidence uploaded yet
                  </p>
                  <Button
                    onClick={() => navigate(`/cases/${id}/upload-evidence`)}
                    className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload First Evidence
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
