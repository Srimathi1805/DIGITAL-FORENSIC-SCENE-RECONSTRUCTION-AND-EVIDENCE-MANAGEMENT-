import { useMember } from '@/integrations';
import { motion } from 'framer-motion';
import { User, Mail, Calendar, Shield } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { format } from 'date-fns';
import { Image } from '@/components/ui/image';

export default function ProfilePage() {
  const { member } = useMember();

  const profileData = [
    {
      icon: User,
      label: 'Display Name',
      value: member?.profile?.nickname || 'Not set'
    },
    {
      icon: Mail,
      label: 'Email',
      value: member?.loginEmail || 'Not available'
    },
    {
      icon: Calendar,
      label: 'Member Since',
      value: member?._createdDate ? format(new Date(member._createdDate), 'MMMM dd, yyyy') : 'Unknown'
    },
    {
      icon: Shield,
      label: 'Status',
      value: member?.status || 'UNKNOWN'
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <main className="max-w-[100rem] mx-auto px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-8">
            <h1 className="font-heading text-5xl font-bold mb-4">User Profile</h1>
            <p className="font-paragraph text-lg text-foreground/70">
              Manage your account information and settings
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Profile Card */}
            <Card className="lg:col-span-1 bg-code-background border-primary/20">
              <CardHeader>
                <CardTitle className="font-heading text-2xl">Profile Overview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center text-center">
                  {member?.profile?.photo?.url ? (
                    <Image src={member.profile.photo.url} alt={member?.profile?.nickname || 'User'} className="w-32 h-32 rounded-full border-4 border-primary/30 mb-4" />
                  ) : (
                    <div className="w-32 h-32 rounded-full bg-primary/10 border-4 border-primary/30 flex items-center justify-center mb-4">
                      <User className="w-16 h-16 text-primary" />
                    </div>
                  )}
                  <h2 className="font-heading text-2xl font-bold">
                    {member?.contact?.firstName && member?.contact?.lastName
                      ? `${member.contact.firstName} ${member.contact.lastName}`
                      : member?.profile?.nickname || 'User'}
                  </h2>
                  {member?.profile?.title && (
                    <p className="font-paragraph text-sm text-foreground/60 mt-2">
                      {member.profile.title}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Details Card */}
            <Card className="lg:col-span-2 bg-code-background border-primary/20">
              <CardHeader>
                <CardTitle className="font-heading text-2xl">Account Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {profileData.map((item, index) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      className="flex items-start gap-4 p-4 rounded-lg bg-background/50 border border-primary/10"
                    >
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <item.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-paragraph text-sm text-foreground/60 mb-1">
                          {item.label}
                        </p>
                        <p className="font-paragraph font-medium text-foreground break-words">
                          {item.value}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {member?.contact?.phones && member.contact.phones.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: 0.4 }}
                    className="mt-6 p-4 rounded-lg bg-background/50 border border-primary/10"
                  >
                    <p className="font-paragraph text-sm text-foreground/60 mb-2">
                      Phone Numbers
                    </p>
                    <div className="space-y-1">
                      {member.contact.phones.map((phone, idx) => (
                        <p key={idx} className="font-paragraph font-medium text-foreground">
                          {phone}
                        </p>
                      ))}
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
