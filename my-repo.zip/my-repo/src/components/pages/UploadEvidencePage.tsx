import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useMember } from '@/integrations';
import { BaseCrudService } from '@/integrations';
import { Cases, Evidence, ActivityLogs } from '@/entities';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { ArrowLeft, Upload, Plus, X } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

interface EvidenceForm {
  id: string;
  imageUrl: string;
  category: string;
  location: string;
  notes: string;
}

export default function UploadEvidencePage() {
  const { id } = useParams<{ id: string }>();
  const { member } = useMember();
  const navigate = useNavigate();
  const [caseData, setCaseData] = useState<Cases | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [evidenceForms, setEvidenceForms] = useState<EvidenceForm[]>([
    { id: crypto.randomUUID(), imageUrl: '', category: '', location: '', notes: '' }
  ]);

  useEffect(() => {
    if (id) {
      loadCase();
    }
  }, [id]);

  const loadCase = async () => {
    setIsLoading(true);
    try {
      const result = await BaseCrudService.getById<Cases>('cases', id!);
      setCaseData(result);
    } catch (error) {
      console.error('Failed to load case:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addEvidenceForm = () => {
    setEvidenceForms(prev => [
      ...prev,
      { id: crypto.randomUUID(), imageUrl: '', category: '', location: '', notes: '' }
    ]);
  };

  const removeEvidenceForm = (formId: string) => {
    if (evidenceForms.length === 1) return;
    setEvidenceForms(prev => prev.filter(f => f.id !== formId));
  };

  const updateEvidenceForm = (formId: string, field: string, value: string) => {
    setEvidenceForms(prev =>
      prev.map(f => (f.id === formId ? { ...f, [field]: value } : f))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const validForms = evidenceForms.filter(f => f.imageUrl.trim() || f.category.trim());

      for (const form of validForms) {
        const newEvidence: Evidence = {
          _id: crypto.randomUUID(),
          evidenceImage: form.imageUrl || 'https://static.wixstatic.com/media/a478a7_7449ffff60f0440ab9b6d5807d98f4b0~mv2.png?originWidth=768&originHeight=576',
          category: form.category,
          location: form.location,
          notes: form.notes,
          timestamp: new Date().toISOString()
        };

        await BaseCrudService.create('evidence', newEvidence);
      }

      // Log activity
      const activityLog: ActivityLogs = {
        _id: crypto.randomUUID(),
        actionType: 'EVIDENCE_UPLOADED',
        performedBy: member?.profile?.nickname || member?.loginEmail || 'Unknown',
        timestamp: new Date().toISOString(),
        description: `Uploaded ${validForms.length} evidence item(s) to case: ${caseData?.title}`,
        relatedEntityId: id,
        relatedEntityType: 'case'
      };
      await BaseCrudService.create('activitylogs', activityLog);

      navigate(`/cases/${id}`);
    } catch (error) {
      console.error('Failed to upload evidence:', error);
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh] flex items-center justify-center">
          <LoadingSpinner />
        </main>
        <Footer />
      </div>
    );
  }

  if (!caseData) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <h2 className="font-heading text-3xl font-bold mb-4">Case Not Found</h2>
            <Button
              onClick={() => navigate('/cases')}
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md"
            >
              Back to Cases
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <main className="max-w-[100rem] mx-auto px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Back Button */}
          <Button
            onClick={() => navigate(`/cases/${id}`)}
            variant="ghost"
            className="mb-8 text-foreground/70 hover:text-primary hover:bg-primary/10 rounded-md"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Case Details
          </Button>

          {/* Header */}
          <div className="mb-12">
            <h1 className="font-heading text-5xl font-bold mb-4">Upload Evidence</h1>
            <p className="font-paragraph text-lg text-foreground/70">
              Case: {caseData.title}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-8">
            {evidenceForms.map((form, index) => (
              <motion.div
                key={form.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="bg-code-background border-primary/20">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="font-heading text-xl">Evidence Item #{index + 1}</CardTitle>
                    {evidenceForms.length > 1 && (
                      <Button
                        type="button"
                        onClick={() => removeEvidenceForm(form.id)}
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:bg-destructive/10 rounded-md"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Image URL */}
                    <div className="space-y-2">
                      <Label htmlFor={`imageUrl-${form.id}`} className="font-paragraph font-medium">
                        Image URL
                      </Label>
                      <Input
                        id={`imageUrl-${form.id}`}
                        type="url"
                        value={form.imageUrl}
                        onChange={(e) => updateEvidenceForm(form.id, 'imageUrl', e.target.value)}
                        placeholder="https://example.com/evidence-image.jpg"
                        className="bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
                      />
                      <p className="font-paragraph text-xs text-foreground/50">
                        Leave empty to use placeholder image
                      </p>
                    </div>

                    {/* Category */}
                    <div className="space-y-2">
                      <Label htmlFor={`category-${form.id}`} className="font-paragraph font-medium">
                        Category
                      </Label>
                      <Input
                        id={`category-${form.id}`}
                        type="text"
                        value={form.category}
                        onChange={(e) => updateEvidenceForm(form.id, 'category', e.target.value)}
                        placeholder="e.g., Weapon, Footprint, Blood Stain, Document"
                        className="bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
                      />
                    </div>

                    {/* Location */}
                    <div className="space-y-2">
                      <Label htmlFor={`location-${form.id}`} className="font-paragraph font-medium">
                        Location Found
                      </Label>
                      <Input
                        id={`location-${form.id}`}
                        type="text"
                        value={form.location}
                        onChange={(e) => updateEvidenceForm(form.id, 'location', e.target.value)}
                        placeholder="Specific location where evidence was found"
                        className="bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
                      />
                    </div>

                    {/* Notes */}
                    <div className="space-y-2">
                      <Label htmlFor={`notes-${form.id}`} className="font-paragraph font-medium">
                        Notes
                      </Label>
                      <Textarea
                        id={`notes-${form.id}`}
                        value={form.notes}
                        onChange={(e) => updateEvidenceForm(form.id, 'notes', e.target.value)}
                        placeholder="Additional notes and observations"
                        rows={4}
                        className="bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph resize-none"
                      />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}

            {/* Add More Button */}
            <Button
              type="button"
              onClick={addEvidenceForm}
              variant="outline"
              className="w-full border-primary/30 text-primary hover:bg-primary/10 rounded-md font-paragraph font-semibold py-6"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Another Evidence Item
            </Button>

            {/* Submit Buttons */}
            <div className="flex gap-4 pt-6">
              <Button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 font-paragraph font-semibold py-6 rounded-md"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                    Uploading Evidence...
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5 mr-2" />
                    Upload All Evidence
                  </>
                )}
              </Button>
              <Button
                type="button"
                onClick={() => navigate(`/cases/${id}`)}
                variant="outline"
                disabled={isSubmitting}
                className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md font-paragraph font-semibold px-8 py-6"
              >
                Cancel
              </Button>
            </div>
          </form>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
