import { useState, useEffect } from 'react';
import { BaseCrudService } from '@/integrations';
import { Cases } from '@/entities';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Plus, MapPin, Calendar, User, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { format } from 'date-fns';

export default function CasesPage() {
  const navigate = useNavigate();
  const [cases, setCases] = useState<Cases[]>([]);
  const [filteredCases, setFilteredCases] = useState<Cases[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [hasNext, setHasNext] = useState(false);
  const [skip, setSkip] = useState(0);
  const limit = 12;

  useEffect(() => {
    loadCases();
  }, [skip]);

  useEffect(() => {
    filterCases();
  }, [searchQuery, cases]);

  const loadCases = async () => {
    setIsLoading(true);
    try {
      const result = await BaseCrudService.getAll<Cases>('cases', {}, { limit, skip });
      if (skip === 0) {
        setCases(result.items);
      } else {
        setCases(prev => [...prev, ...result.items]);
      }
      setHasNext(result.hasNext);
    } catch (error) {
      console.error('Failed to load cases:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterCases = () => {
    if (!searchQuery.trim()) {
      setFilteredCases(cases);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = cases.filter(
      (c) =>
        c.title?.toLowerCase().includes(query) ||
        c.description?.toLowerCase().includes(query) ||
        c.location?.toLowerCase().includes(query) ||
        c.assignedOfficer?.toLowerCase().includes(query)
    );
    setFilteredCases(filtered);
  };

  const loadMore = () => {
    setSkip(prev => prev + limit);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
            <div>
              <h1 className="font-heading text-5xl font-bold mb-4">Case Management</h1>
              <p className="font-paragraph text-lg text-foreground/70">
                Manage and track all forensic investigations
              </p>
            </div>
            <Button
              onClick={() => navigate('/cases/new')}
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-paragraph font-semibold px-6 py-6 rounded-md"
            >
              <Plus className="w-5 h-5 mr-2" />
              Create New Case
            </Button>
          </div>

          {/* Search Bar */}
          <div className="mb-8">
            <div className="relative max-w-2xl">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-foreground/40" />
              <Input
                type="text"
                placeholder="Search cases by title, location, officer, or description..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 py-6 bg-code-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
              />
            </div>
          </div>

          {/* Cases Grid */}
          <div className="min-h-[400px]">
            {isLoading && skip === 0 ? null : filteredCases.length > 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4 }}
                className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                {filteredCases.map((caseItem, index) => (
                  <motion.div
                    key={caseItem._id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                  >
                    <Card
                      onClick={() => navigate(`/cases/${caseItem._id}`)}
                      className="bg-code-background border-primary/20 hover:border-primary/40 transition-all cursor-pointer h-full"
                      style={{ boxShadow: '0 0 15px rgba(0, 255, 255, 0.1)' }}
                    >
                      <CardContent className="p-6">
                        <div className="mb-4">
                          <h3 className="font-heading text-xl font-bold mb-2 line-clamp-2">
                            {caseItem.title}
                          </h3>
                          <p className="font-paragraph text-sm text-foreground/60 line-clamp-3">
                            {caseItem.description}
                          </p>
                        </div>

                        <div className="space-y-2 mb-4">
                          {caseItem.location && (
                            <div className="flex items-center gap-2 text-sm font-paragraph text-foreground/70">
                              <MapPin className="w-4 h-4 text-primary" />
                              <span>{caseItem.location}</span>
                            </div>
                          )}
                          {caseItem.incidentDate && (
                            <div className="flex items-center gap-2 text-sm font-paragraph text-foreground/70">
                              <Calendar className="w-4 h-4 text-primary" />
                              <span>{format(new Date(caseItem.incidentDate), 'MMM dd, yyyy')}</span>
                            </div>
                          )}
                          {caseItem.assignedOfficer && (
                            <div className="flex items-center gap-2 text-sm font-paragraph text-foreground/70">
                              <User className="w-4 h-4 text-primary" />
                              <span>{caseItem.assignedOfficer}</span>
                            </div>
                          )}
                        </div>

                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full text-primary hover:bg-primary/10 rounded-md"
                        >
                          View Details
                          <ArrowRight className="ml-2 w-4 h-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-16">
                <p className="font-paragraph text-lg text-foreground/60">
                  {searchQuery ? 'No cases match your search criteria.' : 'No cases found. Create your first case to get started.'}
                </p>
              </div>
            )}
          </div>

          {/* Load More */}
          {hasNext && !searchQuery && (
            <div className="flex justify-center mt-12">
              <Button
                onClick={loadMore}
                disabled={isLoading}
                variant="outline"
                className="border-primary text-primary hover:bg-primary/10 rounded-md font-paragraph font-semibold px-8 py-6"
              >
                {isLoading ? 'Loading...' : 'Load More Cases'}
              </Button>
            </div>
          )}
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
