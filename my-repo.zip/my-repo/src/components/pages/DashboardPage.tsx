import { useState, useEffect } from 'react';
import { useMember } from '@/integrations';
import { BaseCrudService } from '@/integrations';
import { Cases, Evidence, ActivityLogs } from '@/entities';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FolderOpen, Image as ImageIcon, Activity, Plus, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { format } from 'date-fns';

export default function DashboardPage() {
  const { member } = useMember();
  const navigate = useNavigate();
  const [stats, setStats] = useState({ totalCases: 0, totalEvidence: 0, recentActivity: 0 });
  const [recentCases, setRecentCases] = useState<Cases[]>([]);
  const [recentActivities, setRecentActivities] = useState<ActivityLogs[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      const [casesResult, evidenceResult, activitiesResult] = await Promise.all([
        BaseCrudService.getAll<Cases>('cases', {}, { limit: 5 }),
        BaseCrudService.getAll<Evidence>('evidence', {}, { limit: 100 }),
        BaseCrudService.getAll<ActivityLogs>('activitylogs', {}, { limit: 10 })
      ]);

      setStats({
        totalCases: casesResult.totalCount,
        totalEvidence: evidenceResult.totalCount,
        recentActivity: activitiesResult.totalCount
      });

      setRecentCases(casesResult.items);
      setRecentActivities(activitiesResult.items);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const statCards = [
    {
      title: 'Total Cases',
      value: stats.totalCases,
      icon: FolderOpen,
      color: 'primary',
      description: 'Active investigations'
    },
    {
      title: 'Evidence Items',
      value: stats.totalEvidence,
      icon: ImageIcon,
      color: 'secondary',
      description: 'Uploaded evidence'
    },
    {
      title: 'Activity Logs',
      value: stats.recentActivity,
      icon: Activity,
      color: 'accent-muted',
      description: 'System events'
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Welcome Section */}
          <div className="mb-12">
            <h1 className="font-heading text-5xl font-bold mb-4">
              Welcome back, {member?.profile?.nickname || member?.contact?.firstName || 'Officer'}
            </h1>
            <p className="font-paragraph text-lg text-foreground/70">
              Command center overview and system status
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {isLoading ? (
              <>
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-40 bg-code-background rounded-lg border border-primary/10 animate-pulse" />
                ))}
              </>
            ) : (
              statCards.map((stat, index) => (
                <motion.div
                  key={stat.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <Card className="bg-code-background border-primary/20 hover:border-primary/40 transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className={`w-12 h-12 rounded-lg bg-${stat.color}/10 flex items-center justify-center`}>
                          <stat.icon className={`w-6 h-6 text-${stat.color}`} />
                        </div>
                        <div className="text-right">
                          <p className="font-heading text-4xl font-bold">{stat.value}</p>
                        </div>
                      </div>
                      <h3 className="font-heading text-lg font-semibold mb-1">{stat.title}</h3>
                      <p className="font-paragraph text-sm text-foreground/60">{stat.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            )}
          </div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mb-12"
          >
            <h2 className="font-heading text-3xl font-bold mb-6">Quick Actions</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-primary/10 to-transparent border-primary/30 hover:border-primary/50 transition-all cursor-pointer"
                onClick={() => navigate('/cases/new')}
              >
                <CardContent className="p-8">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-lg bg-primary/20 flex items-center justify-center">
                      <Plus className="w-7 h-7 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-heading text-xl font-bold mb-1">Create New Case</h3>
                      <p className="font-paragraph text-sm text-foreground/70">Start a new investigation</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-secondary/10 to-transparent border-secondary/30 hover:border-secondary/50 transition-all cursor-pointer"
                onClick={() => navigate('/cases')}
              >
                <CardContent className="p-8">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-lg bg-secondary/20 flex items-center justify-center">
                      <FolderOpen className="w-7 h-7 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-heading text-xl font-bold mb-1">View All Cases</h3>
                      <p className="font-paragraph text-sm text-foreground/70">Browse investigations</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>

          {/* Recent Cases and Activity */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Recent Cases */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Card className="bg-code-background border-primary/20">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="font-heading text-2xl">Recent Cases</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate('/cases')}
                    className="text-primary hover:text-primary/80 hover:bg-primary/10"
                  >
                    View All
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-20 bg-background/50 rounded-lg animate-pulse" />
                      ))}
                    </div>
                  ) : recentCases.length > 0 ? (
                    <div className="space-y-4">
                      {recentCases.map((caseItem) => (
                        <div
                          key={caseItem._id}
                          onClick={() => navigate(`/cases/${caseItem._id}`)}
                          className="p-4 rounded-lg bg-background/50 border border-primary/10 hover:border-primary/30 transition-all cursor-pointer"
                        >
                          <h4 className="font-heading font-semibold mb-2">{caseItem.title}</h4>
                          <div className="flex flex-wrap gap-4 text-sm font-paragraph text-foreground/60">
                            {caseItem.location && <span>📍 {caseItem.location}</span>}
                            {caseItem.assignedOfficer && <span>👤 {caseItem.assignedOfficer}</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="font-paragraph text-foreground/60 text-center py-8">
                      No cases found. Create your first case to get started.
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Recent Activity */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <Card className="bg-code-background border-primary/20">
                <CardHeader>
                  <CardTitle className="font-heading text-2xl">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="h-16 bg-background/50 rounded-lg animate-pulse" />
                      ))}
                    </div>
                  ) : recentActivities.length > 0 ? (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {recentActivities.map((activity) => (
                        <div
                          key={activity._id}
                          className="p-3 rounded-lg bg-background/50 border border-primary/10"
                        >
                          <div className="flex items-start gap-3">
                            <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="font-paragraph text-sm font-medium mb-1">
                                {activity.actionType}
                              </p>
                              <p className="font-paragraph text-xs text-foreground/60 mb-1">
                                {activity.description}
                              </p>
                              {activity.timestamp && (
                                <p className="font-paragraph text-xs text-foreground/50">
                                  {format(new Date(activity.timestamp), 'MMM dd, yyyy HH:mm')}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="font-paragraph text-foreground/60 text-center py-8">
                      No recent activity to display.
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
