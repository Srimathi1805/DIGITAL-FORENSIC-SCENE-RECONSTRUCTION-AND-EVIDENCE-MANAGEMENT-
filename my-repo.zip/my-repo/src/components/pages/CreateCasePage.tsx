import { useState } from 'react';
import { useMember } from '@/integrations';
import { BaseCrudService } from '@/integrations';
import { Cases, ActivityLogs } from '@/entities';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, MapPin, Calendar, User } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function CreateCasePage() {
  const { member } = useMember();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    incidentDate: '',
    assignedOfficer: member?.profile?.nickname || member?.contact?.firstName || ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const newCase: Cases = {
        _id: crypto.randomUUID(),
        title: formData.title,
        description: formData.description,
        location: formData.location,
        incidentDate: formData.incidentDate ? new Date(formData.incidentDate).toISOString() : undefined,
        assignedOfficer: formData.assignedOfficer
      };

      await BaseCrudService.create('cases', newCase);

      // Log activity
      const activityLog: ActivityLogs = {
        _id: crypto.randomUUID(),
        actionType: 'CASE_CREATED',
        performedBy: member?.profile?.nickname || member?.loginEmail || 'Unknown',
        timestamp: new Date().toISOString(),
        description: `Created new case: ${formData.title}`,
        relatedEntityId: newCase._id,
        relatedEntityType: 'case'
      };
      await BaseCrudService.create('activitylogs', activityLog);

      navigate(`/cases/${newCase._id}`);
    } catch (error) {
      console.error('Failed to create case:', error);
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <main className="max-w-[100rem] mx-auto px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Back Button */}
          <Button
            onClick={() => navigate('/cases')}
            variant="ghost"
            className="mb-8 text-foreground/70 hover:text-primary hover:bg-primary/10 rounded-md"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Cases
          </Button>

          {/* Header */}
          <div className="mb-12">
            <h1 className="font-heading text-5xl font-bold mb-4">Create New Case</h1>
            <p className="font-paragraph text-lg text-foreground/70">
              Initialize a new forensic investigation
            </p>
          </div>

          {/* Form */}
          <Card className="bg-code-background border-primary/20 max-w-4xl">
            <CardHeader>
              <CardTitle className="font-heading text-2xl">Case Information</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Title */}
                <div className="space-y-2">
                  <Label htmlFor="title" className="font-paragraph font-medium">
                    Case Title *
                  </Label>
                  <Input
                    id="title"
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => handleChange('title', e.target.value)}
                    placeholder="Enter case title"
                    className="bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description" className="font-paragraph font-medium">
                    Description *
                  </Label>
                  <Textarea
                    id="description"
                    required
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="Provide detailed case description"
                    rows={6}
                    className="bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph resize-none"
                  />
                </div>

                {/* Location */}
                <div className="space-y-2">
                  <Label htmlFor="location" className="font-paragraph font-medium">
                    Location
                  </Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-foreground/40" />
                    <Input
                      id="location"
                      type="text"
                      value={formData.location}
                      onChange={(e) => handleChange('location', e.target.value)}
                      placeholder="Crime scene location"
                      className="pl-10 bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
                    />
                  </div>
                </div>

                {/* Incident Date */}
                <div className="space-y-2">
                  <Label htmlFor="incidentDate" className="font-paragraph font-medium">
                    Incident Date
                  </Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-foreground/40" />
                    <Input
                      id="incidentDate"
                      type="date"
                      value={formData.incidentDate}
                      onChange={(e) => handleChange('incidentDate', e.target.value)}
                      className="pl-10 bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
                    />
                  </div>
                </div>

                {/* Assigned Officer */}
                <div className="space-y-2">
                  <Label htmlFor="assignedOfficer" className="font-paragraph font-medium">
                    Assigned Officer
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-foreground/40" />
                    <Input
                      id="assignedOfficer"
                      type="text"
                      value={formData.assignedOfficer}
                      onChange={(e) => handleChange('assignedOfficer', e.target.value)}
                      placeholder="Officer name"
                      className="pl-10 bg-background border-primary/20 focus:border-primary/50 rounded-md font-paragraph"
                    />
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex gap-4 pt-6">
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 font-paragraph font-semibold py-6 rounded-md"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                        Creating Case...
                      </>
                    ) : (
                      <>
                        <Save className="w-5 h-5 mr-2" />
                        Create Case
                      </>
                    )}
                  </Button>
                  <Button
                    type="button"
                    onClick={() => navigate('/cases')}
                    variant="outline"
                    disabled={isSubmitting}
                    className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md font-paragraph font-semibold px-8 py-6"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
