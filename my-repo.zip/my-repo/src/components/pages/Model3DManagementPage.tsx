import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { BaseCrudService } from '@/integrations';
import { _3DModels, Cases } from '@/entities';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { ArrowLeft } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Model3DUploader from '@/components/Model3DUploader';
import Model3DGallery from '@/components/Model3DGallery';

export default function Model3DManagementPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [caseData, setCaseData] = useState<Cases | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (id) {
      loadCaseData();
    }
  }, [id]);

  const loadCaseData = async () => {
    setIsLoading(true);
    try {
      const caseResult = await BaseCrudService.getById<Cases>('cases', id!);
      setCaseData(caseResult);
    } catch (error) {
      console.error('Failed to load case:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleModelCreated = () => {
    setRefreshKey((prev) => prev + 1);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh] flex items-center justify-center">
          <LoadingSpinner />
        </main>
        <Footer />
      </div>
    );
  }

  if (!caseData) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <main className="max-w-[100rem] mx-auto px-8 py-16 min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <h2 className="font-heading text-3xl font-bold mb-4">Case Not Found</h2>
            <Button
              onClick={() => navigate('/cases')}
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md"
            >
              Back to Cases
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />

      <main className="max-w-[100rem] mx-auto px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Back Button */}
          <Button
            onClick={() => navigate(`/cases/${id}`)}
            variant="ghost"
            className="mb-8 text-foreground/70 hover:text-primary hover:bg-primary/10 rounded-md"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Case
          </Button>

          {/* Header */}
          <div className="mb-12">
            <h1 className="font-heading text-5xl font-bold mb-4">3D Model Management</h1>
            <p className="font-paragraph text-lg text-foreground/70">
              Case: {caseData.title}
            </p>
          </div>

          {/* Upload Section */}
          <div className="mb-12">
            <Model3DUploader caseId={id!} onModelCreated={handleModelCreated} />
          </div>

          {/* Gallery Section */}
          <div key={refreshKey}>
            <Model3DGallery caseId={id!} onModelsChange={handleModelCreated} />
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
