// HPI 1.7-G
import React, { useRef } from 'react';
import { useMember } from '@/integrations';
import { useNavigate } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Shield, Database, Scan, FileText, ArrowRight, Lock, Terminal, Activity, Cpu, Crosshair, Layers } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Image } from '@/components/ui/image';

export default function HomePage() {
  const { isAuthenticated, actions } = useMember();
  const navigate = useNavigate();

  // CANONICAL DATA SOURCE - PRESERVED EXACTLY
  const features = [
    {
      icon: Shield,
      title: 'Case Management',
      description: 'Create, organize, and track forensic investigations with comprehensive case details and officer assignments.'
    },
    {
      icon: Database,
      title: 'Evidence Repository',
      description: 'Upload and categorize digital evidence with metadata, timestamps, and location tracking for complete documentation.'
    },
    {
      icon: Scan,
      title: '3D Scene Reconstruction',
      description: 'Transform multiple evidence images into interactive 3D models using advanced computer vision technology.'
    },
    {
      icon: FileText,
      title: 'Report Generation',
      description: 'Generate comprehensive case reports with evidence documentation and 3D reconstruction previews for court proceedings.'
    }
  ];

  // Refs for scroll animations
  const heroRef = useRef<HTMLDivElement>(null);
  const processRef = useRef<HTMLDivElement>(null);
  const featuresRef = useRef<HTMLDivElement>(null);

  // Scroll transforms
  const { scrollYProgress: heroProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });
  const heroY = useTransform(heroProgress, [0, 1], ["0%", "40%"]);
  const heroOpacity = useTransform(heroProgress, [0, 0.8], [1, 0]);

  const { scrollYProgress: processProgress } = useScroll({
    target: processRef,
    offset: ["start end", "end start"]
  });
  const processLineHeight = useTransform(processProgress, [0, 1], ["0%", "100%"]);

  // Animation Variants
  const fadeUp = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30 selection:text-primary overflow-clip">
      <style>
        {`
          .tech-grid {
            background-size: 40px 40px;
            background-image: 
              linear-gradient(to right, rgba(0, 255, 255, 0.05) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(0, 255, 255, 0.05) 1px, transparent 1px);
            mask-image: linear-gradient(to bottom, black 40%, transparent 100%);
          }
          .scan-line {
            background: linear-gradient(to bottom, transparent, rgba(0, 255, 255, 0.5), transparent);
            animation: scan 4s linear infinite;
          }
          @keyframes scan {
            0% { transform: translateY(-100%); }
            100% { transform: translateY(1000%); }
          }
          .clip-hex {
            clip-path: polygon(10% 0, 100% 0, 100% 90%, 90% 100%, 0 100%, 0 10%);
          }
          .clip-angle {
            clip-path: polygon(0 0, 100% 0, 100% 85%, 85% 100%, 0 100%);
          }
        `}
      </style>

      <Header />

      {/* HERO SECTION - Immersive, Parallax, Techy */}
      <section ref={heroRef} className="relative w-full min-h-[100vh] flex items-center pt-20 overflow-hidden">
        {/* Dynamic Background */}
        <motion.div 
          style={{ y: heroY, opacity: heroOpacity }}
          className="absolute inset-0 z-0"
        >
          <div className="absolute inset-0 tech-grid" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/80 to-background" />
          
          {/* Abstract glowing orbs */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-[30rem] h-[30rem] bg-secondary/10 rounded-full blur-[150px]" />
        </motion.div>

        <div className="w-full max-w-[120rem] mx-auto px-6 lg:px-12 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            
            {/* Hero Content */}
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
              className="lg:col-span-7 space-y-8"
            >
              <motion.div variants={fadeUp} className="inline-flex items-center gap-3 px-4 py-2 rounded-none border border-primary/30 bg-primary/5 backdrop-blur-sm relative overflow-hidden group">
                <div className="absolute inset-0 w-full h-full scan-line opacity-50" />
                <Lock className="w-4 h-4 text-primary relative z-10" />
                <span className="text-xs tracking-widest uppercase font-mono text-primary relative z-10">Secure Protocol Active</span>
              </motion.div>
              
              <motion.h1 variants={fadeUp} className="font-heading text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.1] tracking-tight">
                DIGITAL FORENSIC
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mt-2">
                  COMMAND CENTER
                </span>
              </motion.h1>
              
              <motion.p variants={fadeUp} className="font-paragraph text-lg md:text-xl text-foreground/70 leading-relaxed max-w-2xl border-l-2 border-primary/50 pl-6">
                Advanced evidence management and 3D scene reconstruction platform. 
                Precision-engineered for the digital realm. Transform fragmented data into undeniable truth.
              </motion.p>
              
              <motion.div variants={fadeUp} className="flex flex-wrap gap-6 pt-8">
                {isAuthenticated ? (
                  <>
                    <Button
                      onClick={() => navigate('/dashboard')}
                      className="bg-primary text-primary-foreground hover:bg-primary/80 font-heading font-bold px-10 py-7 text-lg rounded-none clip-angle transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,255,255,0.4)]"
                    >
                      ACCESS DASHBOARD
                      <ArrowRight className="ml-3 w-5 h-5" />
                    </Button>
                    <Button
                      onClick={() => navigate('/cases')}
                      variant="outline"
                      className="border-primary/50 text-primary hover:bg-primary/10 font-heading font-bold px-10 py-7 text-lg rounded-none transition-all duration-300"
                    >
                      VIEW CASES
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      onClick={actions.login}
                      className="bg-primary text-primary-foreground hover:bg-primary/80 font-heading font-bold px-10 py-7 text-lg rounded-none clip-angle transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,255,255,0.4)]"
                    >
                      INITIALIZE LOGIN
                      <ArrowRight className="ml-3 w-5 h-5" />
                    </Button>
                    <Button
                      onClick={actions.login}
                      variant="outline"
                      className="border-primary/50 text-primary hover:bg-primary/10 font-heading font-bold px-10 py-7 text-lg rounded-none transition-all duration-300"
                    >
                      REQUEST ACCESS
                    </Button>
                  </>
                )}
              </motion.div>
            </motion.div>
            
            {/* Hero Visual - Terminal / Data Feed */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.4, ease: "easeOut" }}
              className="lg:col-span-5 relative"
            >
              <div className="relative bg-code-background/80 backdrop-blur-md border border-primary/20 p-1 clip-hex shadow-[0_0_40px_rgba(0,255,255,0.1)]">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
                <div className="bg-[#111] p-6 h-[500px] flex flex-col font-mono text-sm relative overflow-hidden clip-hex">
                  
                  {/* Decorative UI elements */}
                  <div className="flex justify-between items-center border-b border-primary/20 pb-4 mb-4">
                    <div className="flex gap-2">
                      <div className="w-2 h-2 bg-destructive animate-pulse" />
                      <div className="w-2 h-2 bg-secondary" />
                      <div className="w-2 h-2 bg-primary" />
                    </div>
                    <span className="text-primary/50 text-xs">SYS.OP.v2.4.1</span>
                  </div>

                  <div className="space-y-3 flex-1 overflow-hidden relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#111] z-10 pointer-events-none" />
                    <motion.div 
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.8 }}
                      className="text-accent-muted flex items-center gap-2"
                    >
                      <Terminal className="w-4 h-4" />
                      <span>$ init_forensic_core --verbose</span>
                    </motion.div>
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }} className="text-foreground/50">
                      [SYS] Establishing secure connection to central database...
                    </motion.div>
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }} className="text-primary">
                      [OK] Authentication protocols verified.
                    </motion.div>
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.8 }} className="text-primary">
                      [OK] Evidence vault synchronized.
                    </motion.div>
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2.1 }} className="text-secondary flex items-center gap-2">
                      <Activity className="w-4 h-4" />
                      <span>[ACTIVE] 3D Reconstruction Engine online.</span>
                    </motion.div>
                    
                    {/* Simulated data stream */}
                    <div className="pt-4 space-y-1 opacity-40 text-xs">
                      <div className="truncate">0x8F2A: Loading spatial mapping algorithms...</div>
                      <div className="truncate">0x8F2B: Calibrating photogrammetry sensors...</div>
                      <div className="truncate">0x8F2C: Awaiting image dataset input...</div>
                    </div>
                  </div>

                  <div className="mt-auto pt-4 border-t border-primary/20 flex justify-between items-center text-xs">
                    <span className="text-primary animate-pulse">READY FOR INPUT_</span>
                    <span className="text-foreground/40">CPU: 12% | MEM: 4.2GB</span>
                  </div>
                </div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* STICKY NARRATIVE SECTION - The Process */}
      <section ref={processRef} className="relative w-full bg-background border-t border-primary/10">
        <div className="w-full max-w-[120rem] mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16">
            
            {/* Sticky Left Column */}
            <div className="lg:h-screen lg:sticky lg:top-0 flex flex-col justify-center py-20 lg:py-0">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-20%" }}
                className="space-y-6"
              >
                <div className="flex items-center gap-4">
                  <div className="h-[1px] w-12 bg-primary" />
                  <span className="text-primary font-mono text-sm tracking-widest uppercase">Operational Flow</span>
                </div>
                <h2 className="font-heading text-4xl lg:text-6xl font-bold leading-tight">
                  From Fragmented Data to <br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Spatial Reality.</span>
                </h2>
                <p className="font-paragraph text-lg text-foreground/60 max-w-md">
                  Our proprietary pipeline ingests raw 2D evidence and synthesizes it into a navigable, millimeter-accurate 3D environment, preserving the integrity of the scene indefinitely.
                </p>
              </motion.div>
            </div>

            {/* Scrolling Right Column */}
            <div className="py-20 lg:py-[30vh] space-y-[20vh] relative">
              {/* Vertical Progress Line */}
              <div className="absolute left-8 top-0 bottom-0 w-[1px] bg-primary/10 hidden lg:block">
                <motion.div 
                  className="w-full bg-gradient-to-b from-primary via-secondary to-primary"
                  style={{ height: processLineHeight }}
                />
              </div>

              {/* Step 1 */}
              <motion.div 
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-20%" }}
                className="relative pl-0 lg:pl-24"
              >
                <div className="absolute left-[-5px] top-6 w-3 h-3 rounded-full bg-background border-2 border-primary hidden lg:block z-10" />
                <div className="bg-code-background/50 border border-primary/20 p-8 clip-angle backdrop-blur-sm">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-primary/10 flex items-center justify-center border border-primary/30">
                      <Database className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-heading text-2xl font-bold">1. Data Ingestion</h3>
                  </div>
                  <p className="font-paragraph text-foreground/70 mb-6">
                    Securely upload hundreds of high-resolution photographs from the scene. The system automatically extracts EXIF data, timestamps, and spatial metadata.
                  </p>
                  <div className="aspect-video relative overflow-hidden border border-primary/20">
                    <Image 
                      src="https://static.wixstatic.com/media/a478a7_1dce1e89d4f84235aaf2d23439e2f67c~mv2.png?originWidth=960&originHeight=512" 
                      alt="Data ingestion interface"
                      className="w-full h-full object-cover opacity-60 mix-blend-luminosity hover:mix-blend-normal transition-all duration-700"
                    />
                    <div className="absolute inset-0 bg-primary/10 mix-blend-overlay" />
                  </div>
                </div>
              </motion.div>

              {/* Step 2 */}
              <motion.div 
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-20%" }}
                className="relative pl-0 lg:pl-24"
              >
                <div className="absolute left-[-5px] top-6 w-3 h-3 rounded-full bg-background border-2 border-secondary hidden lg:block z-10" />
                <div className="bg-code-background/50 border border-secondary/20 p-8 clip-angle backdrop-blur-sm">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-secondary/10 flex items-center justify-center border border-secondary/30">
                      <Cpu className="w-6 h-6 text-secondary" />
                    </div>
                    <h3 className="font-heading text-2xl font-bold">2. Photogrammetric Processing</h3>
                  </div>
                  <p className="font-paragraph text-foreground/70 mb-6">
                    Advanced computer vision algorithms analyze overlapping images, identifying millions of tie points to calculate depth and spatial relationships.
                  </p>
                  <div className="aspect-video relative overflow-hidden border border-secondary/20">
                    <Image 
                      src="https://static.wixstatic.com/media/a478a7_9b15aefe70d04d1a9a76d21d6768ece4~mv2.png?originWidth=960&originHeight=512" 
                      alt="Processing visualization"
                      className="w-full h-full object-cover opacity-60 mix-blend-luminosity hover:mix-blend-normal transition-all duration-700"
                    />
                    <div className="absolute inset-0 bg-secondary/10 mix-blend-overlay" />
                    {/* Simulated processing overlay */}
                    <div className="absolute inset-0 tech-grid opacity-30" />
                  </div>
                </div>
              </motion.div>

              {/* Step 3 */}
              <motion.div 
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-20%" }}
                className="relative pl-0 lg:pl-24"
              >
                <div className="absolute left-[-5px] top-6 w-3 h-3 rounded-full bg-background border-2 border-primary hidden lg:block z-10" />
                <div className="bg-code-background/50 border border-primary/20 p-8 clip-angle backdrop-blur-sm">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-primary/10 flex items-center justify-center border border-primary/30">
                      <Layers className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-heading text-2xl font-bold">3. 3D Synthesis</h3>
                  </div>
                  <p className="font-paragraph text-foreground/70 mb-6">
                    A fully textured, interactive 3D mesh is generated. Investigators can navigate the scene, measure distances, and analyze sightlines virtually.
                  </p>
                  <div className="aspect-video relative overflow-hidden border border-primary/20">
                    <Image 
                      src="https://static.wixstatic.com/media/a478a7_5a3b736266c24945817ec7bb2f5ac054~mv2.png?originWidth=960&originHeight=512" 
                      alt="3D Model output"
                      className="w-full h-full object-cover opacity-80 transition-all duration-700 hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                  </div>
                </div>
              </motion.div>

            </div>
          </div>
        </div>
      </section>

      {/* VISUAL BREATHER - Full Bleed Data Visualization */}
      <section className="w-full h-[80vh] relative overflow-hidden border-y border-primary/20">
        <div className="absolute inset-0 bg-primary/5 z-10 mix-blend-overlay" />
        <div className="absolute inset-0 tech-grid opacity-20 z-10" />
        <Image 
          src="https://static.wixstatic.com/media/a478a7_ca7c09eaf11040b1b7d38745fec27232~mv2.png?originWidth=1920&originHeight=1280" 
          alt="Abstract forensic data visualization"
          className="w-full h-full object-cover opacity-40 mix-blend-luminosity"
        />
        
        <div className="absolute inset-0 z-20 flex items-center justify-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="text-center p-12 backdrop-blur-md bg-background/40 border border-primary/30 clip-hex max-w-4xl mx-4"
          >
            <Crosshair className="w-12 h-12 text-primary mx-auto mb-6 opacity-80" />
            <h2 className="font-heading text-3xl md:text-5xl font-bold mb-4 tracking-wide">
              PRECISION DOWN TO THE MILLIMETER
            </h2>
            <p className="font-mono text-primary/80 text-sm md:text-base tracking-widest uppercase">
              Absolute fidelity in digital reconstruction.
            </p>
          </motion.div>
        </div>
      </section>

      {/* FEATURES SECTION - Asymmetrical Grid */}
      <section id="features" ref={featuresRef} className="w-full bg-background py-32 relative">
        <div className="w-full max-w-[120rem] mx-auto px-6 lg:px-12">
          
          <div className="mb-20 flex flex-col md:flex-row md:items-end justify-between gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-2xl"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="h-[1px] w-12 bg-secondary" />
                <span className="text-secondary font-mono text-sm tracking-widest uppercase">System Modules</span>
              </div>
              <h2 className="font-heading text-4xl lg:text-6xl font-bold">
                Core Capabilities
              </h2>
            </motion.div>
            <motion.p 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="font-paragraph text-foreground/60 max-w-md border-l border-primary/30 pl-6"
            >
              A comprehensive suite of tools designed to maintain the chain of custody while providing unparalleled analytical power.
            </motion.p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Map through canonical features array */}
            {features.map((feature, index) => {
              // Create an asymmetrical layout by making the first item span 2 columns on large screens
              const isLarge = index === 0;
              
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className={`group relative bg-code-background/30 border border-primary/10 p-8 hover:bg-code-background/60 transition-all duration-500 overflow-hidden ${isLarge ? 'lg:col-span-2 lg:row-span-2 p-12' : ''}`}
                >
                  {/* Hover Effects */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-700 origin-left" />
                  
                  <div className="relative z-10 h-full flex flex-col">
                    <div className={`mb-8 flex items-center justify-center bg-background border border-primary/20 ${isLarge ? 'w-20 h-20' : 'w-14 h-14'}`}>
                      <feature.icon className={`${isLarge ? 'w-10 h-10' : 'w-6 h-6'} text-primary group-hover:scale-110 transition-transform duration-500`} />
                    </div>
                    
                    <h3 className={`font-heading font-bold mb-4 ${isLarge ? 'text-4xl' : 'text-2xl'}`}>
                      {feature.title}
                    </h3>
                    
                    <p className={`font-paragraph text-foreground/60 leading-relaxed mt-auto ${isLarge ? 'text-lg max-w-xl' : 'text-base'}`}>
                      {feature.description}
                    </p>

                    {/* Decorative corner bracket */}
                    <div className="absolute bottom-4 right-4 w-4 h-4 border-b border-r border-primary/30 group-hover:border-primary transition-colors duration-300" />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA SECTION - Terminal Interface */}
      <section className="w-full py-32 relative overflow-hidden bg-[#0a0a0a]">
        <div className="absolute inset-0 tech-grid opacity-10" />
        
        <div className="w-full max-w-[80rem] mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="border border-primary/30 bg-code-background/80 backdrop-blur-xl p-1 shadow-[0_0_50px_rgba(0,255,255,0.05)]"
          >
            <div className="border border-primary/20 p-12 lg:p-20 text-center relative overflow-hidden">
              {/* Scanning line effect */}
              <div className="absolute inset-0 w-full h-full scan-line opacity-20 pointer-events-none" />
              
              <Shield className="w-16 h-16 text-primary mx-auto mb-8 opacity-80" />
              
              <h2 className="font-heading text-4xl lg:text-5xl font-bold mb-6 uppercase tracking-wide">
                Initiate Investigation Protocol
              </h2>
              
              <p className="font-mono text-foreground/60 mb-12 max-w-2xl mx-auto text-sm leading-relaxed">
                System ready. Awaiting authorized personnel to commence data ingestion and scene reconstruction. Ensure all credentials are valid before proceeding.
              </p>
              
              <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
                {isAuthenticated ? (
                  <Button
                    onClick={() => navigate('/dashboard')}
                    className="bg-primary text-primary-foreground hover:bg-primary/80 font-heading font-bold px-12 py-8 text-lg rounded-none clip-angle w-full sm:w-auto transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,255,255,0.3)]"
                  >
                    ENTER SYSTEM
                    <ArrowRight className="ml-3 w-5 h-5" />
                  </Button>
                ) : (
                  <Button
                    onClick={actions.login}
                    className="bg-primary text-primary-foreground hover:bg-primary/80 font-heading font-bold px-12 py-8 text-lg rounded-none clip-angle w-full sm:w-auto transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,255,255,0.3)]"
                  >
                    AUTHENTICATE
                    <Lock className="ml-3 w-5 h-5" />
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}