import { useState, useRef } from 'react';
import { BaseCrudService } from '@/integrations';
import { _3DModels } from '@/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Upload, FileText, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

interface Model3DUploaderProps {
  caseId: string;
  onModelCreated?: (model: _3DModels) => void;
}

export default function Model3DUploader({ caseId, onModelCreated }: Model3DUploaderProps) {
  const [uploadMode, setUploadMode] = useState<'image' | 'glb'>('image');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const simulateProcessing = async (duration: number) => {
    return new Promise((resolve) => {
      const startTime = Date.now();
      const interval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min((elapsed / duration) * 100, 99);
        setProcessingProgress(progress);
        
        if (elapsed >= duration) {
          clearInterval(interval);
          setProcessingProgress(100);
          resolve(null);
        }
      }, 100);
    });
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setSelectedFile(file);
  };

  const handleImageUpload = async () => {
    if (!selectedFile) {
      setError('Please select an image file');
      return;
    }

    setIsProcessing(true);
    setProcessingProgress(0);
    setError(null);

    try {
      // Read file as data URL
      const reader = new FileReader();
      reader.onload = async (e) => {
        const imageUrl = e.target?.result as string;
        
        // Simulate 3D reconstruction processing (3-8 seconds)
        const processingTime = Math.random() * 5000 + 3000;
        await simulateProcessing(processingTime);

        // Create model entry
        const model: _3DModels = {
          _id: crypto.randomUUID(),
          modelName: selectedFile.name.replace(/\.[^/.]+$/, ''),
          modelUrl: imageUrl,
          caseId: caseId,
          modelType: 'reconstructed',
          creationTimestamp: new Date().toISOString(),
          processingTimeSeconds: Math.round(processingTime / 1000),
          description: `3D model reconstructed from ${selectedFile.name}`
        };

        await BaseCrudService.create('3dmodels', model);
        
        setSelectedFile(null);
        setProcessingProgress(0);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
        onModelCreated?.(model);
      };
      reader.readAsDataURL(selectedFile);
    } catch (err) {
      setError('Failed to process image. Please try again.');
      console.error('Upload error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleGLBUpload = async () => {
    if (!selectedFile) {
      setError('Please select a GLB file');
      return;
    }

    setIsProcessing(true);
    setProcessingProgress(0);
    setError(null);

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const glbUrl = e.target?.result as string;

        // Create model entry (immediate display for GLB)
        const model: _3DModels = {
          _id: crypto.randomUUID(),
          modelName: selectedFile.name.replace(/\.[^/.]+$/, ''),
          modelUrl: glbUrl,
          caseId: caseId,
          modelType: 'glb',
          creationTimestamp: new Date().toISOString(),
          processingTimeSeconds: 0,
          description: `GLB model: ${selectedFile.name}`
        };

        await BaseCrudService.create('3dmodels', model);
        
        setSelectedFile(null);
        setProcessingProgress(100);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
        onModelCreated?.(model);
      };
      reader.readAsDataURL(selectedFile);
    } catch (err) {
      setError('Failed to upload GLB file. Please try again.');
      console.error('Upload error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card className="bg-code-background border-primary/20">
      <CardHeader>
        <CardTitle className="font-heading text-2xl">Upload 3D Model</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Mode Selection */}
          <div className="flex gap-4">
            <button
              onClick={() => {
                setUploadMode('image');
                setSelectedFile(null);
                setError(null);
              }}
              className={`flex-1 py-3 px-4 rounded-lg font-paragraph font-medium transition-all ${
                uploadMode === 'image'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-background border border-primary/20 text-foreground hover:border-primary/40'
              }`}
            >
              📸 Image to 3D
            </button>
            <button
              onClick={() => {
                setUploadMode('glb');
                setSelectedFile(null);
                setError(null);
              }}
              className={`flex-1 py-3 px-4 rounded-lg font-paragraph font-medium transition-all ${
                uploadMode === 'glb'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-background border border-primary/20 text-foreground hover:border-primary/40'
              }`}
            >
              🎯 GLB File
            </button>
          </div>

          {/* File Input */}
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept={uploadMode === 'image' ? 'image/*' : '.glb'}
              onChange={handleFileSelect}
              disabled={isProcessing}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="w-full py-8 px-6 border-2 border-dashed border-primary/30 rounded-lg hover:border-primary/60 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="flex flex-col items-center gap-3">
                <Upload className="w-8 h-8 text-primary/60" />
                <div>
                  <p className="font-paragraph font-medium text-foreground">
                    {selectedFile ? selectedFile.name : 'Click to select file'}
                  </p>
                  <p className="font-paragraph text-sm text-foreground/60 mt-1">
                    {uploadMode === 'image' ? 'PNG, JPG, WebP' : 'GLB format'}
                  </p>
                </div>
              </div>
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3 p-4 rounded-lg bg-destructive/10 border border-destructive/30"
            >
              <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
              <p className="font-paragraph text-sm text-destructive">{error}</p>
            </motion.div>
          )}

          {/* Processing Progress */}
          {isProcessing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-3"
            >
              <div className="flex items-center gap-3">
                <LoadingSpinner />
                <div className="flex-1">
                  <p className="font-paragraph font-medium text-foreground">
                    {uploadMode === 'image' ? 'Reconstructing 3D model...' : 'Uploading GLB...'}
                  </p>
                  <p className="font-paragraph text-sm text-foreground/60">
                    {Math.round(processingProgress)}%
                  </p>
                </div>
              </div>
              <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-primary"
                  initial={{ width: 0 }}
                  animate={{ width: `${processingProgress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </motion.div>
          )}

          {/* Upload Button */}
          {!isProcessing && (
            <Button
              onClick={uploadMode === 'image' ? handleImageUpload : handleGLBUpload}
              disabled={!selectedFile}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed rounded-md font-paragraph font-semibold"
            >
              {uploadMode === 'image' ? 'Start 3D Reconstruction' : 'Upload GLB Model'}
            </Button>
          )}

          {/* Info */}
          <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
            <p className="font-paragraph text-sm text-foreground/70">
              {uploadMode === 'image'
                ? '💡 Upload an image for AI-powered 3D reconstruction (3-8 seconds processing)'
                : '💡 Upload a GLB file for immediate 3D model display'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
