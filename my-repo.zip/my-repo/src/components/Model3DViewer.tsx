import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { AlertCircle, RotateCw, RotateCcw, ZoomIn, ZoomOut, RotateCcwSquare } from 'lucide-react';
import { motion } from 'framer-motion';

interface Model3DViewerProps {
  modelUrl: string;
  modelName: string;
  modelType: 'glb' | 'reconstructed';
  onClose?: () => void;
}

export default function Model3DViewer({
  modelUrl,
  modelName,
  modelType,
  onClose
}: Model3DViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const modelRef = useRef<THREE.Object3D | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const rotationRef = useRef({ x: 0, y: 0 });
  const zoomRef = useRef(5);

  const handleRotateLeft = () => {
    if (modelRef.current) {
      modelRef.current.rotation.y -= 0.3;
    }
  };

  const handleRotateRight = () => {
    if (modelRef.current) {
      modelRef.current.rotation.y += 0.3;
    }
  };

  const handleZoomIn = () => {
    zoomRef.current = Math.max(1, zoomRef.current - 1);
    if (cameraRef.current) {
      cameraRef.current.position.z = zoomRef.current;
    }
  };

  const handleZoomOut = () => {
    zoomRef.current = Math.min(20, zoomRef.current + 1);
    if (cameraRef.current) {
      cameraRef.current.position.z = zoomRef.current;
    }
  };

  const handleResetView = () => {
    if (modelRef.current) {
      modelRef.current.rotation.x = 0;
      modelRef.current.rotation.y = 0;
      modelRef.current.rotation.z = 0;
    }
    zoomRef.current = 5;
    if (cameraRef.current) {
      cameraRef.current.position.z = 5;
    }
    rotationRef.current = { x: 0, y: 0 };
  };

  useEffect(() => {
    if (!containerRef.current) return;

    try {
      // Scene setup with neutral dark background
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x111111);
      sceneRef.current = scene;

      // Camera setup
      const camera = new THREE.PerspectiveCamera(
        75,
        containerRef.current.clientWidth / containerRef.current.clientHeight,
        0.1,
        1000
      );
      camera.position.z = zoomRef.current;
      cameraRef.current = camera;

      // Renderer setup with linear tone mapping for natural colors
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
      renderer.setPixelRatio(window.devicePixelRatio);
      renderer.toneMapping = THREE.LinearToneMapping;
      renderer.toneMappingExposure = 1.0;
      containerRef.current.appendChild(renderer.domElement);
      rendererRef.current = renderer;

      // Enhanced lighting - warm neutral without blue tint
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
      scene.add(ambientLight);

      const directionalLight = new THREE.DirectionalLight(0xfff5e6, 1.0);
      directionalLight.position.set(8, 8, 8);
      directionalLight.castShadow = true;
      scene.add(directionalLight);

      const fillLight = new THREE.DirectionalLight(0xfff5e6, 0.5);
      fillLight.position.set(-8, 4, 8);
      scene.add(fillLight);

      // Load model
      if (modelType === 'glb') {
        const loader = new GLTFLoader();
        loader.load(
          modelUrl,
          (gltf) => {
            const model = gltf.scene;
            modelRef.current = model;

            // Center and scale model
            const box = new THREE.Box3().setFromObject(model);
            const center = box.getCenter(new THREE.Vector3());
            const size = box.getSize(new THREE.Vector3());
            const maxDim = Math.max(size.x, size.y, size.z);
            const scale = 4 / maxDim;

            model.position.sub(center.multiplyScalar(scale));
            model.scale.multiplyScalar(scale);

            scene.add(model);
            setIsLoading(false);
          },
          undefined,
          (err) => {
            console.error('GLB loading error:', err);
            setError('Failed to load 3D model');
            setIsLoading(false);
          }
        );
      } else {
        // For reconstructed models (image-based), create a simple visualization
        const geometry = new THREE.BoxGeometry(2, 2, 2);
        const material = new THREE.MeshPhongMaterial({
          color: 0x00ffff,
          emissive: 0x004444,
          wireframe: false
        });
        const mesh = new THREE.Mesh(geometry, material);
        modelRef.current = mesh;
        scene.add(mesh);

        // Add texture if available
        if (modelUrl.startsWith('data:')) {
          const textureLoader = new THREE.TextureLoader();
          textureLoader.load(modelUrl, (texture) => {
            material.map = texture;
            material.needsUpdate = true;
          });
        }

        setIsLoading(false);
      }

      // Handle window resize
      const handleResize = () => {
        if (!containerRef.current) return;
        const width = containerRef.current.clientWidth;
        const height = containerRef.current.clientHeight;
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
      };

      window.addEventListener('resize', handleResize);

      // Animation loop
      let animationId: number;
      const animate = () => {
        animationId = requestAnimationFrame(animate);

        if (modelRef.current && autoRotate) {
          modelRef.current.rotation.x += 0.005;
          modelRef.current.rotation.y += 0.008;
        }

        renderer.render(scene, camera);
      };

      animate();

      // Cleanup
      return () => {
        window.removeEventListener('resize', handleResize);
        cancelAnimationFrame(animationId);
        renderer.dispose();
        if (containerRef.current?.contains(renderer.domElement)) {
          containerRef.current.removeChild(renderer.domElement);
        }
      };
    } catch (err) {
      console.error('3D viewer error:', err);
      setError('Failed to initialize 3D viewer');
      setIsLoading(false);
    }
  }, [modelType, modelUrl, autoRotate]);

  return (
    <Card className="bg-code-background border-primary/20 overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="font-heading text-2xl">{modelName}</CardTitle>
        <div className="flex gap-2">
          <Button
            onClick={() => setAutoRotate(!autoRotate)}
            variant="outline"
            size="sm"
            className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md"
          >
            <RotateCw className={`w-4 h-4 ${autoRotate ? 'animate-spin' : ''}`} />
          </Button>
          {onClose && (
            <Button
              onClick={onClose}
              variant="outline"
              size="sm"
              className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md"
            >
              Close
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-10">
              <LoadingSpinner />
            </div>
          )}

          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 flex items-center justify-center bg-background/80 z-10"
            >
              <div className="flex flex-col items-center gap-3">
                <AlertCircle className="w-8 h-8 text-destructive" />
                <p className="font-paragraph text-sm text-destructive">{error}</p>
              </div>
            </motion.div>
          )}

          <div
            ref={containerRef}
            className="w-full"
            style={{
              height: '600px',
              background: 'linear-gradient(135deg, #111111 0%, #1a1a1a 100%)',
              border: '1px solid rgba(0, 255, 255, 0.2)',
              borderRadius: '8px',
              boxShadow: '0 0 20px rgba(0, 255, 255, 0.1) inset'
            }}
          />
        </div>

        <div className="p-6 bg-background border-t border-primary/20">
          <div className="flex flex-wrap gap-2 mb-4">
            <Button
              onClick={handleRotateLeft}
              variant="outline"
              size="sm"
              className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Rotate Left
            </Button>
            <Button
              onClick={handleRotateRight}
              variant="outline"
              size="sm"
              className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md flex items-center gap-2"
            >
              <RotateCw className="w-4 h-4" />
              Rotate Right
            </Button>
            <Button
              onClick={handleZoomIn}
              variant="outline"
              size="sm"
              className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md flex items-center gap-2"
            >
              <ZoomIn className="w-4 h-4" />
              Zoom In
            </Button>
            <Button
              onClick={handleZoomOut}
              variant="outline"
              size="sm"
              className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md flex items-center gap-2"
            >
              <ZoomOut className="w-4 h-4" />
              Zoom Out
            </Button>
            <Button
              onClick={handleResetView}
              variant="outline"
              size="sm"
              className="border-primary/30 text-foreground hover:bg-primary/10 rounded-md flex items-center gap-2"
            >
              <RotateCcwSquare className="w-4 h-4" />
              Reset View
            </Button>
          </div>
          <p className="font-paragraph text-xs text-foreground/60">
            {modelType === 'glb' ? '🎯 GLB Model' : '📸 Reconstructed from Image'}
          </p>
          <p className="font-paragraph text-sm text-foreground/80 mt-2">
            💡 Use buttons to control the model • Auto-rotation {autoRotate ? 'enabled' : 'disabled'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
