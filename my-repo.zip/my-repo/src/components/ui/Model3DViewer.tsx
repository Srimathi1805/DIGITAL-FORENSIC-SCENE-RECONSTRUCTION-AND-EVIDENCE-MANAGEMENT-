declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': any;
    }
  }
}
type Props = {
  modelUrl: string | null;
  loading: boolean;
};

export default function Model3DViewer({ modelUrl, loading }: Props) {
  return (
    <div style={{ marginTop: "20px" }}>

      {loading && <p>🔄 Processing 3D reconstruction...</p>}

      {modelUrl && (
        <model-viewer
          src={modelUrl}
          auto-rotate
          camera-controls
          style={{ width: "100%", height: "500px" }}
        />
      )}

    </div>
  );
}
